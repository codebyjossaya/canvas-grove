export const GROVE_ORIGIN = "https://canvas.jcamille.dev";
