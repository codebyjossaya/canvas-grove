export const GROVE_ORIGIN = "https://canvas.jcamille.dev";
export const GROVE_PATTERN = "https://canvas.jcamille.dev/*";
